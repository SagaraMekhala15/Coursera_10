1) Download the file as a zip
2) Open the zip folder after downloading
3) Extract to a desired location
4) open files using VScode or Jupyternotebook
